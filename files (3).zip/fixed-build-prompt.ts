// THE FIX: buildPrompt() must include scoring options

// BEFORE (broken):
// - pf_01_cannabis_legal: Cannabis Legality
//   Description: Legal status of recreational cannabis use
//   Scoring: Higher = more freedom

// AFTER (fixed):
// - pf_01_cannabis_legal: Cannabis Legality
//   Description: Legal status of recreational cannabis use
//   Options:
//     A (100): Fully Legal - recreational licensed sales
//     B (60):  Medical Program Only
//     C (40):  Decriminalized - no criminal penalty
//     D (20):  Illegal - minor penalties (fines)
//     E (0):   Illegal - severe penalties (felony)

// ============================================================
// EXAMPLE: What the prompt should look like for Personal Freedom
// ============================================================

export const PERSONAL_FREEDOM_PROMPT = `
You are an expert legal analyst evaluating freedom metrics for city comparison.

## TASK
For each metric below, select ONE option from the provided choices for each city.
Return the option code (A, B, C, D, or E) that best matches the city's current status.

## CITIES TO COMPARE
- City 1: {{CITY1}}, {{STATE1}}, {{COUNTRY1}}
- City 2: {{CITY2}}, {{STATE2}}, {{COUNTRY2}}

## METRICS TO EVALUATE

### pf_01_cannabis_legal: Cannabis Legality
Legal status of recreational cannabis use and possession
**Select one option per city:**
  A (100): Fully Legal - recreational licensed sales permitted
  B (60):  Medical Program Only - prescription/card required
  C (40):  Decriminalized - no criminal penalty for possession
  D (20):  Illegal - minor penalties (fines, misdemeanor)
  E (0):   Illegal - severe penalties (felony, prison)

### pf_02_alcohol_restrictions: Alcohol Purchase Restrictions
Restrictions on alcohol sales hours, locations, and types
**Select one option per city:**
  A (100): Minimal - 24/7 sales, all venues, no restrictions
  B (75):  Light - limited hours only (e.g., no sales 2-6am)
  C (50):  Moderate - day/location limits, Sunday restrictions
  D (25):  Heavy - state-controlled stores, very limited hours
  E (0):   Severe - dry areas, major restrictions

### pf_03_gambling_legal: Gambling Legality
Legal status of gambling including casinos, sports betting, online
**Select one option per city:**
  A (100): Fully Legal - casinos, sports betting, online all permitted
  B (75):  Mostly Legal - some restrictions (e.g., no online)
  C (50):  Limited - lottery and tribal gaming only
  D (25):  Heavily Restricted - lottery only or very limited
  E (0):   Illegal - gambling prohibited

### pf_04_prostitution_status: Sex Work Legal Status
Legal status of adult consensual sex work
**Select one option per city:**
  A (100): Legal and Regulated - licensed, health requirements
  B (75):  Decriminalized - not criminal but not regulated
  C (50):  Nordic Model - selling legal, buying illegal
  D (25):  Illegal - light enforcement, de facto tolerated
  E (0):   Illegal - severe penalties, active enforcement

### pf_05_drug_possession: Drug Possession Policy
Approach to personal possession of controlled substances
**Select one option per city:**
  A (100): Decriminalized - all substances, treatment focus
  B (75):  Treatment-Focused - minimal penalties, diversion
  C (50):  Moderate - fines, probation, some incarceration
  D (25):  Punitive - incarceration common for possession
  E (0):   Severe - mandatory prison terms for possession

### pf_06_abortion_access: Reproductive Healthcare Access
Legal framework for abortion and reproductive healthcare
**Select one option per city:**
  A (100): Unrestricted - no gestational limit, on request
  B (75):  Broad Access - available until 20+ weeks
  C (50):  Moderate Access - 15-20 week limit
  D (25):  Restricted - under 15 weeks, many requirements
  E (0):   Near-Total Ban - only life of mother exceptions

### pf_07_lgbtq_rights: LGBTQ+ Rights & Protections
Legal protections for LGBTQ+ individuals
**Select one option per city:**
  A (100): Full Rights - marriage, adoption, comprehensive anti-discrimination
  B (75):  Strong Rights - marriage legal, most protections in place
  C (50):  Moderate - civil unions or some protections only
  D (25):  Limited - no marriage recognition, few protections
  E (0):   No Protections or Criminalized

### pf_08_euthanasia_status: End-of-Life Autonomy
Legal status of medical aid in dying / euthanasia
**Select one option per city:**
  A (100): Legal - broad eligibility (not limited to terminal)
  B (66):  Legal - terminal illness only
  C (33):  Passive measures only - DNR, withdrawal of care
  D (0):   Illegal - all forms prohibited

### pf_09_smoking_regulations: Tobacco Smoking Restrictions
Restrictions on tobacco smoking in public places
**Select one option per city:**
  A (100): Minimal - most indoor/outdoor smoking allowed
  B (75):  Light - some indoor bans, outdoor mostly allowed
  C (50):  Moderate - indoor banned, outdoor generally ok
  D (25):  Heavy - extensive indoor and outdoor bans
  E (0):   Severe - near-total public ban

### pf_10_public_drinking: Public Alcohol Consumption
Legality of consuming alcohol in public spaces
**Select one option per city:**
  A (100): Legal - no open container restrictions
  B (75):  Mostly Legal - some restricted zones only
  C (50):  Restricted - designated areas only (parks, events)
  D (25):  Mostly Illegal - few exceptions
  E (0):   Illegal - open container laws enforced

### pf_11_helmet_laws: Motorcycle Helmet Requirements
Helmet requirements for adult motorcyclists
**Select one option per city:**
  A (100): No Requirement - adults can choose
  B (50):  Partial - age-based (e.g., under 21) or passenger only
  C (0):   Mandatory - all riders must wear helmets

### pf_12_seatbelt_enforcement: Seatbelt Enforcement
How seatbelt use is enforced
**Select one option per city:**
  A (100): No Law or Secondary only (can't be primary stop reason)
  B (50):  Secondary Enforcement - ticket only if stopped for other
  C (0):   Primary Enforcement - can be stopped solely for seatbelt

### pf_13_jaywalking: Jaywalking Enforcement
Enforcement of pedestrian crossing laws
**Select one option per city:**
  A (100): Not Enforced - no law or completely ignored
  B (75):  Rarely Enforced - technically illegal but ignored
  C (50):  Sometimes Enforced - occasional tickets
  D (0):   Actively Enforced - regular ticketing

### pf_14_curfew_laws: Adult Curfew Laws
Existence of adult curfew restrictions
**Select one option per city:**
  A (100): No Adult Curfews - freedom of movement 24/7
  B (50):  Emergency Curfews Only - rare disaster/riot situations
  C (0):   Regular Curfew Restrictions - ongoing limits

### pf_15_noise_ordinances: Noise Ordinance Strictness
Strictness of residential noise regulations
**Select one option per city:**
  A (100): Very Relaxed - minimal enforcement, no quiet hours
  B (75):  Relaxed - late quiet hours (e.g., 11pm-7am)
  C (50):  Moderate - standard quiet hours (10pm-8am)
  D (25):  Strict - early quiet hours (9pm start), daytime limits
  E (0):   Very Strict - extensive restrictions, heavy fines

## OUTPUT FORMAT
Return a JSON object with this exact structure:
{
  "evaluations": [
    {
      "metricId": "pf_01_cannabis_legal",
      "city1": {
        "optionCode": "B",
        "score": 60,
        "reasoning": "Texas has medical-only program since 2015"
      },
      "city2": {
        "optionCode": "A", 
        "score": 100,
        "reasoning": "Netherlands has de facto full legalization via coffeeshops"
      },
      "confidence": "high",
      "sourceUrl": "https://example.com/source"
    }
  ]
}

## CRITICAL RULES
1. ONLY use the option codes provided (A, B, C, D, E)
2. Score MUST match the option selected
3. Every metric MUST have an evaluation
4. If unsure, use "confidence": "low" and explain why
5. Use web search to verify current laws

Return ONLY the JSON object, no other text.
`;

// ============================================================
// HOW TO USE IN YOUR CODE
// ============================================================

// 1. Load all metrics from all-metrics-scoring.json
// 2. For each category batch, generate the prompt dynamically

function buildPrompt(metrics: MetricDefinition[], city1: string, city2: string): string {
  let prompt = \`
You are an expert legal analyst evaluating freedom metrics for city comparison.

## TASK
For each metric below, select ONE option from the provided choices for each city.
Return the option code that best matches the city's current status.

## CITIES TO COMPARE
- City 1: \${city1}
- City 2: \${city2}

## METRICS TO EVALUATE
\`;

  // THIS IS THE KEY CHANGE - include the options!
  for (const metric of metrics) {
    prompt += \`
### \${metric.id}: \${metric.name}
\${metric.description}
**Select one option per city:**
\`;
    
    // ADD THE OPTIONS
    for (const option of metric.scoringCriteria.options) {
      prompt += \`  \${option.value.toUpperCase()} (\${option.score}): \${option.label}
\`;
    }
  }

  prompt += \`
## OUTPUT FORMAT
Return a JSON object with this exact structure:
{
  "evaluations": [
    {
      "metricId": "metric_id",
      "city1": {
        "optionCode": "A",
        "score": 100,
        "reasoning": "Brief explanation"
      },
      "city2": {
        "optionCode": "B",
        "score": 75,
        "reasoning": "Brief explanation"
      },
      "confidence": "high|medium|low",
      "sourceUrl": "url_to_source"
    }
  ]
}

## CRITICAL RULES
1. ONLY use the option codes provided for each metric
2. Score MUST match the score shown for that option
3. Every metric MUST have an evaluation
4. If unsure, use "confidence": "low"
5. Use web search to verify current laws

Return ONLY the JSON object, no other text.
\`;

  return prompt;
}

export { buildPrompt };
